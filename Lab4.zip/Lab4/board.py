import random

DEFAULT_ROWS = 6
DEFAULT_COLS = 6
DEFAULT_MINES = 6


class Board:
    def __init__(self, rows=DEFAULT_ROWS, cols=DEFAULT_COLS, mines=DEFAULT_MINES):
        self.rows = rows
        self.cols = cols
        self.mine_total = mines

        self.mines = set()
        self.revealed = set()
        self.flags = set()

        self._first_move = True

    def _build_mines(self, safe_pos=None):
        cells = [
            (r, c)
            for r in range(self.rows)
            for c in range(self.cols)
            if (r, c) != safe_pos
        ]

        return set(random.sample(cells, self.mine_total))

    def in_bounds(self, r, c):
        return 0 <= r < self.rows and 0 <= c < self.cols

    def neighbors(self, r, c):
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue

                nr = r + dr
                nc = c + dc

                # IMPORTANT: < instead of <=
                if self.in_bounds(nr, nc):
                    yield nr, nc

    def adjacent_mines(self, r, c):
        return sum(
            pos in self.mines
            for pos in self.neighbors(r, c)
        )

    def reveal(self, start):
        # Make the first move guaranteed safe
        if self._first_move:
            self.mines = self._build_mines(start)
            self._first_move = False

        stack = [start]
        hit_mine = False

        while stack:
            pos = stack.pop()

            if pos in self.revealed or pos in self.flags:
                continue

            r, c = pos

            if not self.in_bounds(r, c):
                continue

            self.revealed.add(pos)

            # Mine
            if pos in self.mines:
                hit_mine = True
                continue

            # Empty cell: reveal surrounding cells
            if self.adjacent_mines(r, c) == 0:
                for n in self.neighbors(r, c):
                    if n not in self.revealed:
                        stack.append(n)

        return hit_mine

    def toggle_flag(self, pos):
        if pos in self.revealed:
            return False

        if pos in self.flags:
            self.flags.remove(pos)
        else:
            self.flags.add(pos)

        return True

    def won(self):
        return len(self.revealed) == (
            self.rows * self.cols - self.mine_total
        )